if minetest.get_modpath("bonemeal") then
bonemeal:add_crop({
	{"better_farming:carrot_", 8, "better_farming:carrot_1"},
})
bonemeal:add_crop({
	{"better_farming:tomatoes_", 5, "better_farming:seed_tomatoes"},
})
bonemeal:add_crop({
	{"better_farming:strawberry_", 8, "better_farming:seed_strawberry"},
})
bonemeal:add_crop({
	{"better_farming:onion_", 8, "better_farming:seed_onion"},
})
bonemeal:add_crop({
	{"better_farming:chilie_", 5, "better_farming:seed_chilie"},
})
bonemeal:add_crop({
	{"better_farming:pepper_", 5, "better_farming:seed_pepper"},
})
bonemeal:add_crop({
	{"better_farming:rice_", 8, "better_farming:seed_rice"},
})
bonemeal:add_crop({
	{"better_farming:cabbage_", 6, "better_farming:seed_cabbage"},
})
bonemeal:add_crop({
	{"better_farming:potatoes_", 4, "better_farming:seed_potatoes"},
})
bonemeal:add_crop({
	{"better_farming:aspargus_", 5, "better_farming:seed_aspargus"},
})
bonemeal:add_crop({
	{"better_farming:eggplants_", 4, "better_farming:seed_eggplants"},
})
bonemeal:add_crop({
	{"better_farming:spinach_", 4, "better_farming:seed_spinach"},
})
bonemeal:add_crop({
	{"better_farming:corn_", 8, "better_farming:seed_corn"},
})
bonemeal:add_crop({
	{"better_farming:medecinal_plant_", 4, "better_farming:seed_medecinal_plant"},
})
bonemeal:add_crop({
	{"better_farming:beetroot_", 4, "better_farming:seed_beetroot"},
})
bonemeal:add_crop({
	{"better_farming:ginger_", 4, "better_farming:ginger_seed"},
})
bonemeal:add_crop({
	{"better_farming:mint_", 4, "better_farming:seed_mint"},
})
bonemeal:add_crop({
	{"better_farming:agave_", 3, "better_farming:seed_agave"},
})
bonemeal:add_crop({
	{"better_farming:cassava_", 3, "better_farming:seed_cassava"},
})
bonemeal:add_crop({
	{"better_farming:cucumber_", 4, "better_farming:seed_cucumber"},
})
bonemeal:add_crop({
	{"better_farming:kale_", 3, "better_farming:seed_kale"},
})
bonemeal:add_crop({
	{"better_farming:jute_", 3, "better_farming:seed_jute"},
})
bonemeal:add_crop({
	{"better_farming:yucca_", 3, "better_farming:seed_yucca"},
})
bonemeal:add_crop({
	{"better_farming:aloe_", 3, "better_farming:seed_aloe"},
})
bonemeal:add_crop({
	{"better_farming:millet_", 3, "better_farming:seed_millet"},
})
bonemeal:add_crop({
	{"better_farming:spiceleaf_", 3, "better_farming:seed_spiceleaf"},
})
bonemeal:add_crop({
	{"better_farming:bokchoy_", 3, "better_farming:seed_bokchoy"},
})
bonemeal:add_crop({
	{"better_farming:adzuki_", 7, "better_farming:seed_adzuki"},
})
bonemeal:add_crop({
	{"better_farming:sisal_", 3, "better_farming:seed_sisal"},
})
end
